import React from 'react';

const Header = () => {
  return (
    <header>
      <h1>Quản Lý Chi Tiêu Cá Nhân</h1>
    </header>
  );
};

export default Header;
